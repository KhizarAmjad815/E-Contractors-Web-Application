from django.db import models

# Create your models here.
# This model is used for database

