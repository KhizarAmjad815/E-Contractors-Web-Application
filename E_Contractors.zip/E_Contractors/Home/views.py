from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse, HttpRequest
from django.views import generic
from django.shortcuts import redirect

class TempContractor:

    def __init__(self, service='None', img='None', delay=0.1, description='None', name='None'):
        self.name = name
        self.service = service
        self.img = img
        self.description = description
        self.delay = delay

class HomeView(generic.TemplateView):

    def get_context_data(self, **kwargs):

        c1 = TempContractor('House Construction', 'contractor-1.jpg', 0.1, 'We provide quality contractors who construct and build fascinating houses for our clients')
        c2 = TempContractor('Brick Layer', 'contractor-2.jpg', 0.2)
        c3 = TempContractor('Concrete Finisher', 'contractor-3.jpg', 0.3)
        c4 = TempContractor('Painter', 'contractor-4.jpg', 0.4)
        c5 = TempContractor('Carpenter', 'contractor-5.jpg', 0.5)
        c6 = TempContractor('Electrician', 'contractor-6.jpg', 0.6)
        c7 = TempContractor('Plumber', 'contractor-7.jpg', 0.7)
        c8 = TempContractor('Roof Tiler', 'contractor-8.jpg', 0.8)
        c9 = TempContractor('Mazdoor/Mistri', 'contractor-9.jpg', 0.9)
        contractors = [c1, c2, c3, c4, c5, c6, c7, c8, c9]

        context = super().get_context_data(**kwargs)
        context['contractors'] = contractors

        return context


    def get(self, request, *args, **kwargs):

        if not request.user.is_authenticated:
            return render(request=request, template_name='index.html', context=self.get_context_data())
        else:
            return redirect('profile')



