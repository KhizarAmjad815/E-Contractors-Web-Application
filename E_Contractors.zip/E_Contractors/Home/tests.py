from django.test import TestCase

# Create your tests here.
# For testing our application