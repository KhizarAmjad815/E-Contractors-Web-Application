from django.contrib import admin
from ContactInfo.models import ContactInfo

admin.site.register(ContactInfo)

