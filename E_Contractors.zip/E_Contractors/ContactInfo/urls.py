from django.urls import path
from django.contrib.auth.decorators import login_required
from . import views

urlpatterns = [

    path('contractor/contact_info/view_contact_info/',  login_required(views.ContactInfoView.as_view()), name='view-contactinfo'),
    path('contractor/contact_info/edit_contact_info/',  login_required(views.ContactInfoUpdateView.as_view()), name='edit-contactinfo'),
]

