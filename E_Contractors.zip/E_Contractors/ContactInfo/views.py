from django.shortcuts import render
from django.views import generic
from django.urls import reverse_lazy
from Users.forms import *
from Users.views import is_contractor
from django.contrib.auth import mixins

class ContactInfoView(mixins.UserPassesTestMixin, generic.TemplateView):

    template_name = 'contractor/contact_info/view_contact_info.html'

    def test_func(self):
        return self.request.user.profile.role == 'Contractor'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['user'] = self.request.user
        return context


class ContactInfoUpdateView(mixins.UserPassesTestMixin, generic.UpdateView):

    def test_func(self):
        return self.request.user.profile.role == 'Contractor'

    model = ContactInfo
    form_class = ContactInfoForm
    template_name = 'contractor/contact_info/edit_contact_info.html'
    success_url = reverse_lazy('view-contactinfo')

    def get_object(self, queryset=None):

        return self.request.user.profile.contractor_profile.contact_info

    def get_context_data(self, **kwargs):

        context = super().get_context_data(**kwargs)
        return context

