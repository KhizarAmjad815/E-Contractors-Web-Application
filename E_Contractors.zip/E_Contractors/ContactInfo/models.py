from django.db import models
from django.core.validators import RegexValidator

class ContactInfo(models.Model):

    contact_info_id = models.BigAutoField(primary_key=True)

    contact_email = models.EmailField(null=True, unique=False)

    contact_phone = models.CharField(max_length=255, null=False, unique=False, validators=[RegexValidator(regex='^[\d]{4}-?[\d]{7}$', message='Ensure your phone number is 11 digits long and all numeric')])

    contact_whatsapp = models.CharField(max_length=255, null=False, unique=False, validators=[RegexValidator(regex='^^[\d]{4}-?[\d]{7}$', message='Ensure your whatsapp is 11 digits long and all numeric')])

    class Meta:

        db_table = 'Contact_Info'

    def __str__(self):

        return self.contact_email + ' ' + self.contact_phone + ' ' + self.contact_whatsapp

