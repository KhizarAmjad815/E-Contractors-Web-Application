from django.shortcuts import render, redirect
from .forms import ProfileImageChangeForm, ProfileUpdateForm, SettingsUpdateForm
from django.contrib.auth.decorators import login_required
from .models import UserProfile, Contractor
from django.contrib.auth.models import User
from django.views import generic
from django.urls import reverse_lazy
from django.contrib import messages
from Catalogue.models import Catalogue
from django.http import JsonResponse
from django.contrib.auth import mixins
from Client.models import Contracts

def test_function(request):

    return request.user.profile.role == 'Contractor' and not (
            request.user.profile.contractor_profile.contact_info.contact_email == '')


class DashboardView(mixins.UserPassesTestMixin, generic.TemplateView):

    template_name = 'contractor/dashboard.html'

    def test_func(self):

        return test_function(self.request)

    def get(self, request, *args, **kwargs):

        if 'term' in request.GET:
            title = request.GET.get('term')
            query = Catalogue.objects.filter(contractor=request.user.profile.contractor_profile.contractor_id).filter(title__iregex=title)
            titles = list()

            for service in query:
                titles.append(service.title)
            # print(titles)
            if not titles:
                titles.append("No result found")

            return JsonResponse(titles, safe=False)

        if 'a_contract' in request.GET:
            contract = Contracts.objects.get(pk=request.GET.get('a_contract'))
            contract.contractor_confirmation = True
            contract.save()

        if 'd_contract' in request.GET:
            contract = Contracts.objects.get(pk=request.GET.get('d_contract'))
            contract.contractor_confirmation = False
            contract.is_declined = True
            contract.save()

        if 'c_contract' in request.GET:
            contract = Contracts.objects.get(pk=request.GET.get('c_contract'))
            contract.is_completed = True
            contract.status = True
            contract.save()

        return render(request=request, template_name=self.template_name, context=self.get_context_data(**kwargs))

    def get_context_data(self, **kwargs):

        context = super().get_context_data(**kwargs)

        context['numCatalogs'] = Catalogue.objects.filter(contractor=self.request.user.profile.contractor_profile).count()
        context['contracts'] = Contracts.objects.filter(contractor=self.request.user.profile.contractor_profile)
        context['numClients'] = Contracts.objects.filter(contractor=self.request.user.profile.contractor_profile).exclude(is_declined=True).count()

        print(context['contracts'])

        return context

@login_required()
def profileView(request):

    user = request.user

    if request.method == 'POST':

        print('request is post')
        if request.FILES.get('profile_img', None) is not None:

            form = ProfileImageChangeForm(request.POST, request.FILES)

            if form.is_valid():
                user.profile.profile_img = form.cleaned_data.get('profile_img')
                user.profile.save()
                user.save()

                return redirect( 'contractor-profile' )
        else:
            form = ProfileImageChangeForm()
    else:
        form = ProfileImageChangeForm()

    role = request.user.profile.role

    context = {'user': user, 'form': form, 'role': role}

    if role == 'Contractor':
        context['base_template'] = 'contractor/base.html'
    elif role == 'Client':
        context['base_template'] = 'client/base.html'

    return render(request=request, template_name='profile/view_profile.html', context=context)

'''
    SettingsUpdateView: It updates user settings like username, email and firstname & lastname
'''
class SettingsUpdateView(generic.UpdateView):

    model = User
    form_class = SettingsUpdateForm

    def get_object(self, queryset=None):

        return self.request.user

    def get_context_data(self, **kwargs):

        context = super().get_context_data(**kwargs)
        role = self.request.user.profile.role
        context['role'] = role

        if role == 'Contractor':
            context['base_template'] = 'contractor/base.html'
        elif role == 'Client':
            context['base_template'] = 'client/base.html'

        return context

    def form_valid(self, form):

        user_email = User.objects.get(pk=self.request.user.id).email
        email = form.cleaned_data['email']

        if User.objects.filter(email=email).exists():
            print(email, '**', user_email)
            if email != user_email:
                messages.error(self.request, 'This email has already taken!')
                role = self.request.user.profile.role
                if role == 'Contractor':
                    return redirect('contractor-edit-settings')
                elif role == 'Client':
                    return redirect('client-edit-settings')

        return super().form_valid(form)

    def get_template_names(self):
        return 'profile/edit_settings.html'

    def get_success_url(self):

        if self.request.user.profile.role == 'Contractor':
            return reverse_lazy('contractor-profile')
        elif self.request.user.profile.role == 'Client':
            return reverse_lazy('client-profile')

'''
    ProfileUpdateView: updates user profile such as country, city, area, zip code, DOB etc
'''
class ProfileUpdateView(generic.UpdateView):

    model = UserProfile
    form_class = ProfileUpdateForm

    def get_object(self, queryset=None):

        return self.request.user.profile

    def get_context_data(self, **kwargs):

        context = super().get_context_data(**kwargs)
        role = self.request.user.profile.role
        context['role'] = role

        if role == 'Contractor':
            context['base_template'] = 'contractor/base.html'
        elif role == 'Client':
            context['base_template'] = 'client/base.html'

        return context

    def get_template_names(self):

        return 'profile/edit_profile.html'

    def get_success_url(self):

        if self.request.user.profile.role == 'Contractor':
            return reverse_lazy( 'contractor-profile' )
        elif self.request.user.profile.role == 'Client':
            return reverse_lazy('client-profile')



