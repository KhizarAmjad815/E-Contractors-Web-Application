from django.db import models
from Users.models import UserProfile
from ContactInfo.models import ContactInfo
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.core.validators import RegexValidator

class Contractor(models.Model):

    # Categories for contractors/professionals
    CATEGORIES = (
        ('Main Contractor', 'Main Contractor'),
        ('Brick Layer', 'Brick Layer'),
        ('Painter', 'Painter'),
        ('Carpenter', 'Carpenter'),
        ('Plumber', 'Plumber'),
        ('Landscaper', 'Landscaper'),
    )

    contractor_id = models.BigAutoField(
        primary_key=True)

    category = models.CharField(
        max_length=255,
        choices=CATEGORIES,
        null=False,
        default='Main Contractor',
        db_index=True)

    cnic = models.CharField(
        max_length=15,
        null=True,
        validators=[RegexValidator(regex='^[0-9]{5}-[0-9]{7}-[0-9]{1}$', message='CNIC must be in format #####-#######-# and 15 digits long')])

    is_authorized = models.BooleanField(
        db_index=True,
        default=False)

    company_name = models.CharField(
        max_length=255,
        default='Self',
        null=False,
        db_index=True)

    ratings = models.PositiveSmallIntegerField(null=True)

    contractor_profile = models.OneToOneField(
        to=UserProfile,
        on_delete=models.CASCADE,
        unique=True,
        related_name='contractor_profile')

    contact_info = models.OneToOneField(
        to=ContactInfo,
        on_delete=models.CASCADE,
        unique=True,
        related_name='contact_info')

    def save(self, *args, **kwargs):

        if self.cnic is not None:
            if '-' not in self.cnic:
                self.cnic = '{0}-{1}-{2}'.format(self.cnic[:5], self.cnic[6:13], self.cnic[14:])

        super(Contractor, self).save(*args, **kwargs)

    class Meta:
        db_table = 'Contractor'

    def __str__(self):

        return str(self.contractor_profile) + '. Authorized: ' + str(self.is_authorized)


# @receiver(post_save, sender=UserProfile)
# def create_contractor_profile(sender, instance, created, **kwargs):
#
#     if instance.role == 'Contractor':
#         try:
#             contractor = Contractor.objects.get(contractor_profile=instance)
#         except Contractor.DoesNotExist:
#             contractor = None
#
#         if contractor is None:
#             Contractor.objects.create(contractor_profile=instance)
#             instance.contractor_profile.save()
#         else:
#             print('Duplicate Contractor found')
