from django.contrib import admin
from Contractor.models import Contractor

# Register your models here.

admin.site.register(Contractor)

