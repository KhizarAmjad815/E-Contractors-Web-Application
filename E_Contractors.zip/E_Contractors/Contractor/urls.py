from django.urls import path, include
from django.contrib.auth.decorators import login_required
from . import views

urlpatterns=[

    path('contractor/dashboard/', login_required(views.DashboardView.as_view()), name='contractor-dashboard'),
    path('contractor/profile/view_profile', views.profileView, name='contractor-profile'),
    path('contractor/profile/edit_profile', login_required(views.ProfileUpdateView.as_view()), name='contractor-edit-profile' ),
    path('contractor/edit_settings', login_required(views.SettingsUpdateView.as_view()), name='contractor-edit-settings' ),
    path('', include('ContactInfo.urls')),
]


