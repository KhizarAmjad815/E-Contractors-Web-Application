from datetime import date
from django import forms
from django.contrib.auth.forms import UserChangeForm
from django.contrib.auth.models import User
from .models import UserProfile, Contractor
from django.core.validators import RegexValidator, MaxValueValidator

class ProfileImageChangeForm(forms.ModelForm):

    profile_img = forms.ImageField(widget=forms.FileInput(attrs={'type': 'file', 'id': 'dp'}), required=False)

    class Meta:

        model = UserProfile
        fields = ('profile_img', )

class SettingsUpdateForm(forms.ModelForm):

    first_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}), min_length=3, label='First Name', strip=True)

    last_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}), min_length=3, label='Last Name', strip=True)

    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control'}))

    class Meta:

        model = User
        fields = ('first_name', 'last_name', 'email')

class ProfileUpdateForm(forms.ModelForm):

    country = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control'}), required=False, disabled=True, initial='Pakistan',
        help_text='This field cannot be changed', label='Country')

    city = forms.Select()

    area = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Shahab Pura'}), min_length=5,
        label='Area/Road')

    street_address = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Kent Street Hazard'}), min_length=5,
        label='Street Address')

    phone_number = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'your number...'}), min_length=11,
        label='Phone Number')

    zip_code = forms.CharField(
        widget=forms.TextInput( attrs={'class': 'form-control', 'placeholder': 'zipcoce i.e. 50000'}), max_length=5,
        label='Zip Code', required=False,
        validators=[RegexValidator( regex='^[\d]{5}$', message='Zip code must be 5 characters long & all numeric' )] )

    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), label='DOB', validators=[MaxValueValidator(limit_value=date.today(), message='Date of Birth cannot be in future')])

    bio = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'About you...'}), min_length=10,
        label='Bio')

    # cnic = forms.CharField(
    #     widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '#####-#######-#'}),
    #     min_length=15, max_length=15, label='CNIC', help_text='Enter 13-digit CNIC',
    #     validators=[RegexValidator('^[0-9]{5}-[0-9]{7}-[0-9]{1}$')])
    #
    # company_name = forms.CharField(
    #     widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'CompanyName'}), min_length=5,
    #     label='Company name', required=False)

    class Meta:
        model = UserProfile
        fields = ('country', 'city', 'area', 'street_address', 'phone_number','zip_code', 'date_of_birth', 'bio')

        widgets = {
            'city': forms.Select(
                attrs={'class': 'form-control'}),
        }


