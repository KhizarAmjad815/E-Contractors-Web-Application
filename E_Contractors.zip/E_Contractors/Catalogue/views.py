from django.shortcuts import render
from django.views import generic
from Catalogue.models import Catalogue
from .forms import ServiceForm
from django.urls import reverse_lazy
from django.contrib.auth import mixins

class CatalogueView(mixins.UserPassesTestMixin, generic.ListView):

    model = Catalogue

    paginate_by = 5

    template_name = 'contractor/catalogue/view_catalogue.html'

    def test_func(self):
        return self.request.user.profile.role == 'Contractor'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        if 'sort' in self.request.GET:
            context['filter'] = self.request.GET.get('sort')

        if 'search' in self.request.GET:
            context['search'] = self.request.GET.get('search')

        return context

    def get_queryset(self):

        queryset = Catalogue.objects.filter(contractor=self.request.user.profile.contractor_profile.contractor_id).order_by('service_id')

        if 'search' in self.request.GET:
            print('I am inside search')
            searched_title = self.request.GET.get('search', '')
            print('search title=', searched_title)
            queryset = queryset.filter(title__icontains=searched_title)

        if 'sort' in self.request.GET and 'sort' != '':
            sort_filter = self.request.GET.get('sort')
            print('sort filter=', sort_filter)
            queryset = queryset.order_by(sort_filter)

        return queryset

class ServiceView(mixins.UserPassesTestMixin, generic.DetailView):

    context_object_name = 'service'

    model = Catalogue

    template_name = 'contractor/catalogue/view_service.html'

    def test_func(self):
        return self.request.user.profile.role == 'Contractor'

    def get_object(self, queryset=None):
        obj = super(ServiceView, self).get_object(queryset=queryset)
        return obj


class AddServiceView(mixins.UserPassesTestMixin, generic.CreateView):

    template_name = 'contractor/catalogue/add_service.html'

    model = Catalogue

    form_class = ServiceForm

    success_url = reverse_lazy('view-catalogue')

    def test_func(self):
        return self.request.user.profile.role == 'Contractor'

    def form_valid(self, form):

        service = form.save(commit=False)

        service.contractor = self.request.user.profile.contractor_profile

        service.save()

        return super().form_valid(form)

class ServiceUpdateView(mixins.UserPassesTestMixin, generic.UpdateView):

    model = Catalogue
    form_class = ServiceForm
    template_name = 'contractor/catalogue/edit_service.html'
    success_url = reverse_lazy('view-catalogue')

    def test_func(self):
        return self.request.user.profile.role == 'Contractor'


class ServiceDeleteView(mixins.UserPassesTestMixin, generic.DeleteView):

    model = Catalogue
    success_url = reverse_lazy('view-catalogue')
    template_name = 'contractor/catalogue/service_confirm_delete.html'

    def test_func(self):
        return self.request.user.profile.role == 'Contractor'



