from django.urls import path
from django.contrib.auth.decorators import login_required
from . import views

urlpatterns = [

    path('contractor/catalogue/view_catalogue', login_required(views.CatalogueView.as_view()), name='view-catalogue'),
    path('contractor/catalogue/view_catalogue/view_service/<int:pk>', login_required(views.ServiceView.as_view()), name='view-service'),
    path('contractor/catalogue/view_catalogue/add_service', login_required(views.AddServiceView.as_view()), name='add-service'),
    path('contractor/catalogue/view_catalogue/edit_service/<int:pk>', login_required(views.ServiceUpdateView.as_view()), name='edit-service'),
    path('contractor/catalogue/view_catalogue/delete_service/<int:pk>', login_required(views.ServiceDeleteView.as_view()), name='delete-service'),
]

