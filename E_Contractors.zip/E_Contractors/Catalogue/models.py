from django.db import models
from Contractor.models import Contractor

class Catalogue(models.Model):

    AVAILABILITIES = [
        ('24/7', '24/7'),
        ('Mon-Thu', 'Mon-Thu'),
        ('Mon-Fri', 'Mon-Fri'),
        ('Mon-Sat', 'Mon-Sat'),
        ('Monday', 'Monday'),
        ('Tuesday', 'Tuesday'),
        ('Wednesday', 'Wednesday'),
        ('Thursday', 'Thursday'),
        ('Friday', 'Friday'),
        ('Saturday', 'Saturday'),
        ('Sunday', 'Sunday'),
    ]

    service_id = models.BigAutoField(primary_key=True)

    title = models.CharField(max_length=50, unique=False)

    service_type = models.CharField(max_length=255)

    service_description = models.TextField()

    service_availability = models.CharField(max_length=255, default='24/7', choices=AVAILABILITIES)

    service_cost = models.PositiveBigIntegerField()

    title_img = models.ImageField(upload_to='title_img', null=False)

    detail_img = models.ImageField(upload_to='detail_img', null=True, blank=True)

    contractor = models.ForeignKey(to=Contractor, on_delete=models.CASCADE, related_name='contractor')

    def __str__(self):
        return self.title

    class Meta:

        db_table = 'Catalogue'

