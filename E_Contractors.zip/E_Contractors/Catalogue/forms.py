from django import forms
from Catalogue.models import Catalogue

class ServiceForm(forms.ModelForm):

	class Meta:

		model = Catalogue
		exclude = ['contractor']

		widgets = {
			'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'your service title i.e. Painting House'}),
			'service_type': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'type of service i.e. Paint'}),
			'service_description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Describe your service....'}),
			'service_availability': forms.Select(attrs={'class': 'form-control'}),
			'service_cost': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': '5000'}),
			'title_img': forms.FileInput(attrs={'type': 'file'}),
			'detail_img': forms.FileInput(attrs={'type': 'file'}),
		}

		labels = {
			'title': 'Service Title',
			'service_type': 'Service Category',
			'service_description': 'Service Description',
			'service_availability': 'Service Availability',
			'service_cost': 'Service Cost (PKR)',
			'title_img': 'Title Image',
			'detail_img': 'Detail Services Image',
		}

