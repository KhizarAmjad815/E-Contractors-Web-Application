from django.urls import path
from django.contrib.auth.decorators import login_required
from . import views
from Contractor import views as con_views

urlpatterns = [

    path('client/dashboard', views.showClientDashboard, name='client-dashboard'),
    path('client/profile/view_profile', con_views.profileView, name='client-profile'),
    path('client/profile/edit_profile', login_required(con_views.ProfileUpdateView.as_view()), name='client-edit-profile'),
    path('client/edit_settings', login_required(con_views.SettingsUpdateView.as_view()), name='client-edit-settings'),
    path('client/browse/contractors', views.BrowseContractorsView, name='browse-contractors'),
    path('client/browse/contractors/main-contractors', views.BrowseMainContractorsView, name='browse-main-contractors'),
    path('client/browse/contractors/sub-contractors', views.BrowseSubContractorsView, name='browse-sub-contractors'),
    path('client/browse/contractors/recommended-contractors', views.BrowseRecommendedContractorsView, name='recommended-contractors'),
    path('client/browse/contractors/hire-contractor/<int:pk>', views.HireContractorView, name='hire-contractor'),
    path('client/my-contracts', views.MyContractsView, name='my-contracts'),
    path('client/rate-contractor/<int:pk>', views.RateContractsView, name='rate-contractor'),

]

