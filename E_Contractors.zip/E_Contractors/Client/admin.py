from django.contrib import admin
from Client.models import Client, Contracts

# Register your models here.

admin.site.register( Client )
admin.site.register( Contracts )

