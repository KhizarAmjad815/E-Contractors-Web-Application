import datetime

from django.shortcuts import render
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.urls import reverse_lazy, reverse
from django.db.models import *
from Contractor.models import Contractor
from Catalogue.models import Catalogue
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from Users.views import is_client
from Users.models import CITIES
from Users.forms import CATEGORIES
from django.contrib import messages
from .models import Contracts, Comment

def get_object_list(contractors, request):

    avg_prices = []
    num_catalogues = []
    category = ''
    name = ''
    contractors = contractors.exclude(Q(contact_info__contact_email='') | Q(contact_info__contact_phone='') | Q(contact_info__contact_whatsapp=''))
    contractors = contractors.exclude(contractor_profile__user__first_name='')
    cities = []
    categories = []
    location = ''

    for n, value in CITIES:
        cities.append(n)

    for c1, c2 in CATEGORIES:
        categories.append(c1)

    if 'category' in request.GET:
        category = request.GET.get('category')
        if not category == 'None':
            contractors = contractors.filter(category=category)

    if 'search-contractor' in request.GET:
        name = request.GET.get('search-contractor')
        contractors = contractors.filter(contractor_profile__user__first_name__icontains=name)

    if 'location' in request.GET:
        location = request.GET.get('location')
        if not location == 'None':
            contractors = contractors.filter(contractor_profile__city=location)
        print(contractors)

    for contractor in contractors:
        avg_prices.append(
            Catalogue.objects.filter(contractor=contractor.contractor_id).aggregate(Avg('service_cost')))
        num_catalogues.append(Catalogue.objects.filter(contractor=contractor.contractor_id).count())

    selling_prices = []

    for price in avg_prices:
        for p in price.values():
            if p is None:
                selling_prices.append(0.0)
            else:
                selling_prices.append(p)

    selling_prices = [round(cost, 2) for cost in selling_prices]
    object_list = list(zip(selling_prices, num_catalogues, contractors))

    page = request.GET.get('page', 1)

    paginator = Paginator(object_list=object_list, per_page=5)

    try:
        pages = paginator.page(page)
    except PageNotAnInteger:
        pages = paginator.page(1)
    except EmptyPage:
        pages = paginator.page(paginator.num_pages)

    return {'Catalogues': Catalogue.objects.all(), 'my_object_list': object_list, 'my_list': pages,
            'concategory': category, 'fname': name, 'location': location, 'cities': cities, 'categories': categories}


@login_required()
@user_passes_test(test_func=is_client)
def showClientDashboard(request):

    context = {}

    return render(request, 'client/dashboard.html', context)

@login_required()
@user_passes_test(test_func=is_client)
def BrowseContractorsView(request):

    contractors = Contractor.objects.all()

    context = get_object_list(contractors, request)

    return render(request=request, template_name='client/contractors/contractors_list.html', context=context)

@login_required()
@user_passes_test(test_func=is_client)
def BrowseMainContractorsView(request):

    main_contractors = Contractor.objects.filter(category='Main Contractor')
    context = get_object_list(main_contractors, request)
    return render(request=request, template_name='client/contractors/contractors_list.html', context=context)

@login_required()
@user_passes_test(test_func=is_client)
def BrowseSubContractorsView(request):

    contractors = Contractor.objects.exclude(category='Main Contractor')
    context = get_object_list(contractors, request)
    return render(request=request, template_name='client/contractors/contractors_list.html', context=context)

@login_required()
@user_passes_test(test_func=is_client)
def BrowseRecommendedContractorsView(request):

    contractors = Contractor.objects.filter(contractor_profile__city=request.user.profile.city)

    context = get_object_list(contractors, request)

    context['loc'] = request.user.profile.city

    return render(request=request, template_name='client/contractors/contractors_list.html', context=context)

@login_required()
@user_passes_test(test_func=is_client)
def HireContractorView(request, pk):

    context = {}

    e_contractor = Contractor.objects.get(contractor_id=pk)
    e_services = Catalogue.objects.filter(contractor_id=pk)

    context['e_contractor'] = e_contractor
    context['e_services'] = e_services

    print(e_contractor)
    print(e_services)

    if request.method == 'POST':

        service_title = request.POST['service']
        service = Catalogue.objects.get(title__exact=service_title)
        print(service)
        no_of_days = request.POST['days']

        if no_of_days == '' or int(no_of_days) < 1:
            messages.error(request, message='Total completed days cannot be less than 1')
            return render(request=request, template_name='client/contractors/hire_contractor.html', context=context)

        comment = Comment()
        comment.save()

        contract = Contracts(client=request.user.profile.client_profile, contractor=e_contractor, service=service)
        contract.comment = comment
        contract.duration_in_days = int(no_of_days)
        contract.rating = 0

        contract.save()

        return redirect('my-contracts')

    return render(request=request, template_name='client/contractors/hire_contractor.html', context=context)

@login_required()
@user_passes_test(test_func=is_client)
def MyContractsView(request):

    context = {}
    contracts = Contracts.objects.filter(client=request.user.profile.client_profile)
    filter_search = ''

    if 'filter' in request.GET:
        filter_search = request.GET.get('filter')
        if filter_search == 'approved':
            contracts = contracts.filter(contractor_confirmation=True, status=False)
        elif filter_search == 'completed':
            contracts = contracts.filter(status=True)
        elif filter_search == 'declined':
            contracts = contracts.filter(is_declined=True)
        elif filter_search == 'confirmationwait':
            contracts = contracts.filter(contractor_confirmation=False, is_declined=False)

    contracts = contracts.order_by('-start_date')
    page = request.GET.get('page', 1)

    paginator = Paginator(object_list=contracts, per_page=5)

    try:
        pages = paginator.page(page)
    except PageNotAnInteger:
        pages = paginator.page(1)
    except EmptyPage:
        pages = paginator.page(paginator.num_pages)

    context['contracts'] = pages
    context['filter'] = filter_search

    return render(request=request, template_name='client/contractors/client_contracts.html', context=context)


@login_required()
@user_passes_test(test_func=is_client)
def RateContractsView(request, pk):

    context = {}

    if request.method == 'POST':
        print(request.POST)

        comment_con = request.POST['comment']
        rating = request.POST['rating']
        post_d = datetime.datetime.now()

        contract = Contracts.objects.get(id=pk)
        contract.comment.comment_content = comment_con
        contract.comment.post_date = post_d
        contract.comment.save()
        contract.rating = int(rating)
        contract.contractor.ratings = rating
        contract.contractor.save()
        contract.save()

    return redirect('my-contracts')

