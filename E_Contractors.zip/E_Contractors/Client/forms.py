from django import forms
from Contractor.models import Contractor
from Users.models import UserProfile

class LocationChangeForm(forms.ModelForm):

	city = forms.Select()

	class Meta:

		model = UserProfile
		fields = ['city']

		widgets = {
			'city': forms.Select(attrs={'class': 'form-control loc-select', 'name': 'location', 'id': 'locations', 'value': 'KK'})
		}
