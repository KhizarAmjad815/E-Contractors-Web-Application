from django.apps import AppConfig
from django.template import Library

class CustomerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Client'

register = Library()

@register.filter(name='times')
def times(num):
    return range(num)

