import datetime
from django.db import models
from Users.models import UserProfile
from django.dispatch import receiver
from django.db.models.signals import post_save
from Contractor.models import Contractor
from Catalogue.models import Catalogue

# Create your models here.

class Client(models.Model):

    client_id = models.BigAutoField(primary_key=True)
    client_profile = models.OneToOneField(UserProfile, on_delete=models.CASCADE, unique=True, related_name='client_profile')

    class Meta:
        db_table = 'Client'

    def __str__(self):
        return str(self.client_profile)

class Comment(models.Model):

    comment_id = models.BigAutoField(primary_key=True)
    comment_content = models.CharField(max_length=500)
    post_date = models.DateTimeField(default=datetime.datetime.now())
    predicted_label = models.BooleanField(default=0)
    predicted_rating = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'Comment'

    def __str__(self):
        return self.comment_content

class Contracts(models.Model):

    client = models.ForeignKey(to=Client, on_delete=models.CASCADE, related_name='requested_client')
    contractor = models.ForeignKey(to=Contractor, on_delete=models.CASCADE, related_name='hired_contractor')
    service = models.ForeignKey(to=Catalogue, on_delete=models.CASCADE, null=True, related_name='requested_service')
    comment = models.ForeignKey(to=Comment, on_delete=models.CASCADE, null=True, related_name='client_comment')
    status = models.BooleanField(default=False)
    start_date = models.DateTimeField(default=datetime.datetime.now())
    duration_in_days = models.PositiveBigIntegerField(default=7)
    rating = models.PositiveSmallIntegerField(default=0)
    contractor_confirmation = models.BooleanField(default=False)
    # is_completed = models.BooleanField(default=False)
    is_declined = models.BooleanField(default=False)

    class Meta:
        db_table = 'Contracts'

    def __str__(self):
        return 'Status: ' + str(self.status) + ', ratings: ' + str(self.rating)


