from django.db import models
from django.contrib.auth.models import User
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.core.validators import MaxValueValidator, RegexValidator
from datetime import date, time
import json

# Reading cities from json file

CITIES = []

with open('Users/cities.json') as file:
    cities = json.load(file)

i = 0
for city in cities:
    CITIES.insert(i, (city['city'], city['city']))
    i += 1

CITIES = tuple(CITIES)
# print(CITIES)


# Our UserProfile Model

class UserProfile(models.Model):

    profile_id = models.BigAutoField(primary_key=True)

    role = models.CharField(max_length=255, null=False, db_index=True)

    profile_img = models.ImageField(upload_to='img', null=True, default='img/default.jpg')

    date_of_birth = models.DateField(null=True, validators=[MaxValueValidator(limit_value=date.today, message='Date of Birth cannot be in future')])

    bio = models.CharField(max_length=255, null=True, blank=True)

    country = models.CharField(max_length=255, null=True, default='Pakistan')

    city = models.CharField(max_length=50, null=True, choices=CITIES, default='Sialkot')

    area = models.CharField(max_length=255, null=True, db_index=True)

    street_address = models.CharField(max_length=255, null=True)

    phone_number = models.CharField(max_length=12, null=True, validators=[RegexValidator(regex='^[\d]{4}[\d]{7}$', message='Ensure your phone number is 11 digits long and all numeric')])

    zip_code = models.CharField(max_length=5, null=True)

    user = models.OneToOneField(User, on_delete=models.CASCADE, unique=True, related_name='profile')

    def __str__(self):

        return self.user.first_name + ' ' + self.user.last_name

    class Meta:
        db_table = 'User_Profile'

# @receiver(post_save, sender=User)
# def create_user_profile(sender, instance, created, **kwargs):
#
#     if created:
#         UserProfile.objects.create(user=instance)


