from django.shortcuts import render, redirect
from Users.forms import ClientRegistrationForm, ContractorRegistrationForm, LoginForm, ClientProfileForm, ContractorProfileForm, ContactInfoForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.models import User
from .models import UserProfile
from Client.models import Client
from Contractor.models import Contractor
from ContactInfo.models import ContactInfo
from django.contrib.auth.decorators import login_required, user_passes_test

# Users/Accounts Views => Signup, Login, Logout, FillProfile

def is_client(user):
    return user.profile.role == 'Client'

def is_contractor(user):
    return user.profile.role == 'Contractor'

def signUpAsClientView(request):

    form = ClientRegistrationForm(request.POST or None)

    if request.method == 'POST':

        if form.is_valid():
            if not 'agreement' in request.POST:
                messages.info(request, 'Please agree to EContractors terms to proceed')
                return redirect('signupClient')

            email = form.cleaned_data['email']

            # If form is valid, checking that username & email are not already taken
            if User.objects.filter(email=email).exists():
                messages.error(request, 'This email has already taken!')
                return redirect('signupClient')
            else:
                # user = User.objects.create_user(username=email, email=email, password=email)
                user = form.save()
                user.save()
                profile = UserProfile(user=user, role='Client')
                profile.save()
                customerProfile = Client(client_profile=profile)
                customerProfile.save()
                return redirect('login')

    context = {'form': form, 'role': 'Client'}

    return render(request, 'accounts/signup.html', context)


def signUpAsContractorView(request):

    form = ContractorRegistrationForm(request.POST or None)

    if request.method == 'POST':

        email = request.POST['email']

        if form.is_valid():
            if not 'agreement' in request.POST:
                messages.info(request, 'Please agree to EContractors terms to proceed')
                return redirect('signupContractor')

            if User.objects.filter(email=email).exists():
                messages.info(request, 'This email has already taken!')
                return redirect('signupContractor')
            else:
                user = form.save()
                user.refresh_from_db()
                user.save()

                profile = UserProfile(user=user, role='Contractor')
                profile.save()

                contactInfo = ContactInfo(contact_email='', contact_phone='', contact_whatsapp='')
                contactInfo.save()

                contractorProfile = Contractor(category=form.cleaned_data.get('category'), contractor_profile=profile, contact_info=contactInfo)
                contractorProfile.save()

                # user.profile.role = 'Contractor'
                # user.profile.save()
                # user.profile.contractor_profile.category = form.cleaned_data.get('category')
                # user.profile.contractor_profile.save()
                # print('The profile category is', user.profile.contractor_profile.category, '***')
                return redirect('login')

    return render(request, 'accounts/signup.html', {'form': form, 'role': 'Contractor'})


def logInView(request):

    if request.user.id is not None and request.user.is_authenticated:
        return redirect('profile')

    if request.method == 'POST':
        form = LoginForm(request.POST)
        userName = request.POST['username']
        password = request.POST['password']

        if userName == '' or password == '':
            messages.info(request, 'username or password cannot be empty')
            return redirect('login')

        user = authenticate(request=request, username=userName, password=password)

        if user is None:
            print('No such user found')
            messages.info(request, 'This username or password is incorrect. No such user found.')
        else:
            print('login successful')
            login(request, user)

            # If user do not select 'remember me' option, expire his session after he closes browses
            if not 'remember' in request.POST:
                request.session.set_expiry(value=0)
            else:
                print('Session expiry set for 2 weeks')
                request.session.save()
                request.session.set_expiry(value=1209600) # expiry for 2 weeks

            return redirect('profile')
    else:
        form = LoginForm()

    return render(request, 'accounts/login.html', {'form': form})

@login_required()
def logOut(request):

    logout(request)
    return redirect('login')


@login_required()
def fillUserProfile(request):

    user = request.user
    if user.profile.role == 'Client' or user.profile.role == 'Contractor':
        if not (user.first_name == '' or user.last_name == '' or user.profile.city == '' or user.profile.area == ''):
            if user.profile.role == 'Contractor':
                contactInfo = user.profile.contractor_profile.contact_info
                if contactInfo.contact_phone == '' or contactInfo.contact_whatsapp == '':
                    return redirect('contactInfo')
                if not user.profile.contractor_profile.cnic == '':
                    return redirect('contractor-dashboard')
            return redirect('client-dashboard')

    if request.method == 'POST':

        user = request.user

        if request.user.profile.role == 'Client':
            form = ClientProfileForm(request.POST, request.FILES, instance=user)
        else:
            form = ContractorProfileForm(request.POST, request.FILES, instance=user)

        if form.is_valid():

            user.first_name = form.cleaned_data.get('firstname')
            user.last_name  = form.cleaned_data.get('lastname')
            user.save()

            if request.FILES is not None:
                user.profile.profile_img = form.cleaned_data.get('profile_image')
            user.profile.country = form.cleaned_data.get('country')
            user.profile.city    = form.cleaned_data.get('city')
            user.profile.area = form.cleaned_data.get('area')
            user.profile.street_address = form.cleaned_data.get('street_address')
            user.profile.zip_code = form.cleaned_data.get('zip_code')
            user.profile.date_of_birth = form.cleaned_data.get('date_of_birth')
            user.profile.phone_number = form.cleaned_data.get('phone_number')
            user.profile.bio = form.cleaned_data.get('bio')
            user.profile.save()

            if user.profile.role == 'Contractor':

                user.profile.refresh_from_db()
                user.profile.contractor_profile.company_name = form.cleaned_data.get('companyname')
                user.profile.contractor_profile.cnic = form.cleaned_data.get('cnic')

                user.profile.contractor_profile.save()

            if request.user.profile.role == 'Contractor':
                return redirect('contactInfo')
            else:
                return redirect('client-dashboard')
        else:
            if request.user.profile.role == 'Client':
                role = 'Client'
            else:
                role = 'Contractor'
            print('Form not validated')
    else:
        if request.user.profile.role == 'Client':
            form = ClientProfileForm()
            role = 'Client'
        else:
            form = ContractorProfileForm()
            role = 'Contractor'

    return render(request, 'profile/complete_profile.html', {'form': form, 'role': role})

@login_required()
@user_passes_test(test_func=is_contractor)
def contactInfoView(request):

    form = ContactInfoForm(request.POST or None)

    if request.method == 'POST':

        user = request.user

        if form.is_valid():

            contactInfo = user.profile.contractor_profile.contact_info
            contactInfo.contact_email = form.cleaned_data.get('contact_email')
            contactInfo.contact_phone = form.cleaned_data.get('contact_phone')
            contactInfo.contact_whatsapp = form.cleaned_data.get('contact_whatsapp')

            contactInfo.save()

            return redirect('profile')

    context = {'form': form}

    return render(request, 'profile/complete_contact_info.html', context)

