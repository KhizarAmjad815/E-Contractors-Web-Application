from datetime import date
from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, SetPasswordForm, UserChangeForm, PasswordResetForm
from django.contrib.auth.models import User
from django.core.validators import RegexValidator, MaxValueValidator
from Users.models import UserProfile
from django.core.files.images import get_image_dimensions
from ContactInfo.models import ContactInfo

# Categories for password_reset of contractors/professionals
CATEGORIES = (
    ('Main Contractor', 'Main Contractor'),
    ('Brick Layer', 'Brick Layer'),
    ('Painter', 'Painter'),
    ('Carpenter', 'Carpenter'),
    ('Plumber', 'Plumber'),
    ('Landscaper', 'Landscaper'),
    ('Electrician', 'Electrician'),
    ('Roof Tiler', 'Roof Tiler'),
    ('Concrete Finisher', 'Concrete Finisher'),
)

class ClientRegistrationForm(UserCreationForm):

    username  = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter username'}), label='Username')
    email     = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}), label='Email')
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}), label='Password')
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Repeat password'}), label='Confirm Password')

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def save(self, commit=True):

        user = super(ClientRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']

        if commit:
            user.save()
        return user

class ContractorRegistrationForm(ClientRegistrationForm):

    category = forms.ChoiceField(widget=forms.Select(attrs={'class': 'form-control', 'placeholder': 'Category'}), choices=CATEGORIES, label='Select Category')

    class Meta:

        model = User
        fields = ('username', 'email', 'password1', 'password2', 'category')


class LoginForm(AuthenticationForm):

    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}), label='Password')

    class Meta:
        model = User
        fields = ('username', 'password')


class ForgotPasswordForm(PasswordResetForm):

    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}))

    class Meta:
        model = User
        fields = 'email'

class SetNewPasswordForm(SetPasswordForm):

    new_password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}), label='New Password')
    new_password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Repeat password'}), label='Confirm New Password')

    class Meta:
        model = User
        fields = ('new_password1', 'new_password2')

class ClientProfileForm(forms.ModelForm):

    profile_image = forms.ImageField(widget=forms.FileInput(attrs={'type': 'file'}), required=False, label='Profile Image')

    firstname = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'your first name i.e. Hammad'}),
        min_length=3, max_length=20, label='First Name', strip=True)

    lastname  = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'your first name i.e. Shah'}),
        min_length=3, max_length=20, label='Last Name')

    country  = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control'}), required=False, disabled=True, initial='Pakistan', help_text='This field cannot be changed', label='Country')

    city  = forms.Select()

    area  = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'your area...'}), min_length=5, label='Area/Road')

    street_address  = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'your street...'}), min_length=5, label='Street Address')

    phone_number  = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'your number...'}), min_length=11, max_length=11, label='Phone Number', validators=[RegexValidator(regex='^[\d]{4}[\d]{7}$', message='Ensure your phone number is 11 digits long and all numeric')])

    zip_code  = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'zipcoce i.e. 50000'}), max_length=5, label='Zip Code', required=False, validators=[RegexValidator(regex='^[\d]{5}$', message='Zip code must be 5 characters long & all numeric')])

    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), label='DOB', required=False,
        validators=[MaxValueValidator(limit_value=date.today, message='Date of Birth cannot be in future')])

    bio  = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'About you...'}), min_length=10, label='Bio', required=False)

    class Meta:

        model = UserProfile
        fields = ('profile_image', 'firstname', 'lastname', 'country', 'city', 'area', 'street_address', 'phone_number', 'zip_code', 'date_of_birth', 'bio')
        exclude = ['user', 'role']

        widgets = {
            'city': forms.Select(
                attrs={'class': 'form-control'}),
        }

class ContractorProfileForm(ClientProfileForm):

    cnic = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '#####-#######-#', 'id': 'nic'}),
        min_length=15, max_length=15, label='CNIC', help_text='Enter 13-digit CNIC',
        validators=[RegexValidator(regex='^[0-9]{5}-[0-9]{7}-[0-9]{1}$', message='CNIC must be in format #####-#######-# and 15 digits long')])

    companyname = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'CompanyName'}), label='Company name', required=False)

class ContactInfoForm(forms.ModelForm):

    contact_email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter contact email'}), label='Contact Email')
    contact_phone = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter contact phone number'}), label='Phone Number', min_length=11)
    contact_whatsapp = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter contact Whatsapp number'}), label='WhatsApp Number', min_length=11)

    class Meta:

        model = ContactInfo
        fields = '__all__'

