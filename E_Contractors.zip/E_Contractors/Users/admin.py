from django.contrib import admin
from Users.models import UserProfile

# Register your models here.

admin.site.register(UserProfile)

